package com.backend.clinicaOdontologicaIntegrador.service.impl;

import com.backend.clinicaOdontologicaIntegrador.dto.entrada.turno.TurnoEntradaDto;
import com.backend.clinicaOdontologicaIntegrador.dto.modificacion.TurnoModificacionEntradaDto;
import com.backend.clinicaOdontologicaIntegrador.dto.turno.TurnoSalidaDto;
import com.backend.clinicaOdontologicaIntegrador.entity.turno.Turno;
import com.backend.clinicaOdontologicaIntegrador.repository.ITurnoRepository;
import com.backend.clinicaOdontologicaIntegrador.service.ITurnoService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class TurnoService implements ITurnoService {
    private final Logger LOGGER = LoggerFactory.getLogger(TurnoService.class);

    private ITurnoRepository turnoRepository;
    private ModelMapper modelMapper;

    public TurnoService(ITurnoRepository turnoRepository, ModelMapper modelMapper) {
        this.turnoRepository = turnoRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public TurnoSalidaDto registrarTurno(TurnoEntradaDto turno) {
        return null;
    }

    @Override
    public List<TurnoEntradaDto> listarTurnos() {
        return null;
    }

    @Override
    public TurnoSalidaDto buscarTurnoPorId(Long id) {
        return null;
    }

    @Override
    public TurnoSalidaDto actualizarTurno(TurnoModificacionEntradaDto turno) {
        return null;
    }

    @Override
    public Void eliminarTurno(Long id) {
        return null;
    }


    private void configureMapping(){
        modelMapper.typeMap(TurnoEntradaDto.class, Turno.class)
                .addMappings(mapper -> mapper.map(TurnoEntradaDto::get))
    }
}
