package com.backend.clinicaOdontologicaIntegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class clinicaOdontologicaIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
